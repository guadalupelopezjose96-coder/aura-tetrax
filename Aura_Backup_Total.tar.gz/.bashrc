# =========================================================================
# CONFIGURACIÓN SOBERANA .BASHRC - JEGL 100% PRIVADO & PREMIUM
# =========================================================================

# --- [ ALIAS Y ENTORNO GLOBAL ] ---
alias v-update='pkg update && pkg upgrade -y'
alias v-bunker='cd ~/Aura-Tetrax'

export AUTHOR="JEGL"
export NUCLEOS=76
export JEGL_CORE_DIR="$HOME/JEGL_PROJECTS/Aura_Premium"

# --- [ PROTOCOLO DE INICIO - TETRAX ENGINE PRO ] ---
clear

# 1. Dashboard Visual Térmico
if [ -f ~/Aura-Tetrax/v_thermal_vision.py ]; then
    python ~/Aura-Tetrax/v_thermal_vision.py
fi

# 2. Activación Computacional de Alta Densidad
if [ -f ~/Aura-Tetrax/v_core_unlock_76.py ]; then
    python ~/Aura-Tetrax/v_core_unlock_76.py
fi

# 3. Sintonía Sónica Modular de Reparación (Frecuencia Armónica)
if [ -f ~/Aura-Tetrax/v_audio_repair.sh ]; then
    ~/Aura-Tetrax/v_audio_repair.sh > /dev/null 2>&1 &
fi

# Volcado de estado de seguridad envolviendo texto estático de forma nativa
echo "---- [ SOBERANÍA DIGITAL ACTIVA AL 100% ] ---"

# --- [ SISTEMA INTERACTIVO DE COMANDOS DE DESARROLLO ] ---
alias v-vision='clear && python ~/Aura-Tetrax/v_thermal_vision.py'
alias jegl_core='cd ~/JEGL_Sovereign_Dev'
alias gcommit='git commit -S -m'

# Automatizaciones críticas de resguardo y auditoría legal
alias jegl_sync='for f in *.py; do [[ "$f" != "blindaje_jegl.py" && "$f" != "config_jegl.py" ]] && cp "$f" ~/Aura-Tetrax/backup_scripts/; done'
alias justicia='mkdir -p ~/.config/aura/backups && cp ~/.config/aura/core_config.json ~/.config/aura/backups/ && history -c && clear'

# --- [ CORE ALIASES - AURA INTEL CORE & INTERFAZ MAESTRA ] ---
# Comillas simples estrictas para prevenir expansión prematura de variables en la shell
alias aura='cd $JEGL_CORE_DIR && ./aura_panel.sh'
alias aura-stress='cd $JEGL_CORE_DIR && ./stress_test.sh'

# Función atómica para purificación inmediata de la tabla de procesos paralelos
aura-clean() {
    echo "🧹 Purificando hilos en paralelo..."
    pkill -f law_core_engine || true
    pkill -f sonic_geometry_engine || true
    echo "✅ Tabla de subprocesos unificada y limpia."
}
alias ir_ubuntu='proot-distro login ubuntu --user root --chroot-dir /root/test_render'
export GPG_TTY=$(tty)

# --- JEGL Security Protocol: Auto-Audit ---
echo "[*] Verificando integridad del Ecosistema Aura..."
cd ~/AuraIntelCore
./audit_check.sh
if [ $? -ne 0 ]; then
    echo "[!!!] ALERTA DE SEGURIDAD: Auditoría fallida. Operación bloqueada."
    # Opcional: sleep 5; exit (esto cerraría la sesión si falla)
else
    echo "[+] Sistema listo y verificado."
fi
export GEMINI_API_KEY="AIzaSyBghUrbovW69RM-SihceDLxSe5_BakdyG0" 
# ------------------------------------------
crond
