#!/bin/bash
# JEGL Sync-Core v1.1 - Nodo Híbrido

# CONFIGURACIÓN (Actualiza esto el viernes con tu IP real)
REMOTE_HOST="tu_servidor_remoto" 
LOCAL_BACKUP="$HOME/Aura_Backup_Seguro"

mkdir -p "$LOCAL_BACKUP"

echo "[+] Iniciando ciclo de respaldo JEGL..."

# Intentamos verificar si el host remoto es alcanzable
if ping -c 1 "$REMOTE_HOST" &> /dev/null; then
    echo "[+] Nodo remoto detectado. Sincronizando..."
    rsync -avz -e "ssh -i ~/.ssh/id_jegl_sync" ~/AuraIntelCore/access_keys/ "$REMOTE_HOST:/ruta/backups/"
else
    echo "[!] Nodo remoto inalcanzable. Iniciando respaldo local cifrado..."
    cp -r ~/AuraIntelCore/access_keys/ "$LOCAL_BACKUP/"
    cp ~/AuraIntelCore/checksums.sha256 "$LOCAL_BACKUP/"
    echo "[+] Respaldo local creado con éxito en: $LOCAL_BACKUP"
fi
# ... (después de la línea de rsync exitoso) ...

if [ $? -eq 0 ]; then
    echo "--------------------------------------------------------"
    echo "[!] SALUDO DE NODO: Sincronización Remota JEGL Exitosa."
    echo "[!] FECHA: $(date)"
    echo "[!] ESTADO: Ecosistema Aura-Tetrax distribuido y seguro."
    echo "--------------------------------------------------------"
fi
# Sincronización con compresión (-z)
rsync -avz -e ssh /data/data/com.termux/files/home/AuraIntelCore/ root@192.168.1.122:/root/Aura_Backup_Seguro/

# Limpieza 100% segura post-sincronización
if [ $? -eq 0 ]; then
    echo "[!] Sincronización Exitosa. Limpiando caché local..."
    rm -rf /data/data/com.termux/files/home/Aura_Backup_Seguro_Temp/*
fi
