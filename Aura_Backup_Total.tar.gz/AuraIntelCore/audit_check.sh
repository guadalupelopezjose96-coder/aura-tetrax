#!/bin/bash
# Auditoría JEGL v2.1 - Sincronización Directa

echo "[+] Iniciando auditoría..."

# Leer hash del archivo y binario
EXPECTED=$(head -n 1 checksums.sha256 | awk '{print $1}')
CURRENT=$(sha256sum motor_paralelo | awk '{print $1}')

if [ "$EXPECTED" != "$CURRENT" ]; then
    echo "[!] ALERTA: Desincronización detectada."
    echo "Esperado: $EXPECTED"
    echo "Actual:   $CURRENT"
    exit 1
fi

echo "[+] Integridad del binario: 100% CORRECTA."
exit 0
# ... (tu código de auditoría actual termina aquí) ...

echo "[+] Integridad validada: Firma JEGL confirmada."

# --- NUEVA CAPA DE SEGURIDAD PRO ---
if [ -f "modules/elite_mode.so" ]; then
    read -p "Ingrese Token de Acceso Pro: " INPUT_TOKEN
    if [ ! -f "access_keys/$INPUT_TOKEN.key" ]; then
        echo "[!] ACCESO DENEGADO: Token no autorizado."
        exit 1
    fi
    echo "[+] Acceso Pro validado. Iniciando núcleos..."
fi
if [ $? -eq 0 ]; then
    echo "[+] Integridad validada. Iniciando Sync-Core..."
    ./sync_core.sh
fi
# -----------------------------------

echo "[+] Auditoría finalizada: Sistema 100% íntegro."

