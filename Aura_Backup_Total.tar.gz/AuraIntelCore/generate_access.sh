#!/bin/bash
# Generador de Llaves JEGL-Pro
USER_ID=$1
EXPIRATION=$(date -d "+30 days" +%s)
TOKEN=$(echo "$USER_ID-$EXPIRATION" | sha256sum | cut -d ' ' -f 1)
echo "$TOKEN" > access_keys/${USER_ID}.key
echo "[+] Llave Pro generada para $USER_ID. Válida hasta $EXPIRATION"
