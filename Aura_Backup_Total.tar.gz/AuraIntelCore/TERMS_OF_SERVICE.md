# TERMS OF SERVICE AND ECOSYSTEM DISTRIBUTION POLICY

**Author and Sovereign Identity:** JEGL (José Emanuel Guadalupe López)  
**Applicability:** Universal Core and Proprietary Frameworks  
**Version:** 1.0 (2026)  
**Status:** ACTIVE [100% LEGAL]

---

### 1. UNIVERSAL GRATUITY MANDATE
The architecture known as **Aura Core Basic** is classified as a public-benefit digital asset. It is distributed under an absolute mandate of universal gratuity (100% free of costs). Its purpose is to guarantee digital access, public documentation, and market sustainability.

### 2. PRIVATE PROPRIETARY ASSETS AND EXCLUSIONS
All high-performance architectures, massive parallel computing modules, audio synchronization components, and optimized variants designated under the titles **Tetrax**, **Aura-Tetrax**, **Pro**, and **Elite** versions are explicitly excluded from the universal gratuity mandate. 
* These modules constitute private proprietary assets owned exclusively by **JEGL**.
* Distribution is restricted strictly to closed, private channels as standalone applications.
* Any unauthorized duplication, reverse engineering, extraction, or commercial re-distribution of these assets is strictly prohibited and protected under international trade secret and intellectual property frameworks.

### 3. THIRD-PARTY INTERMEDIARY EXCLUSION
This ecosystem operates on a sovereign infrastructure with strict cryptographic perimeter isolation. 
* Formal exchange, data transit, and logical synchronization matrices are exclusively recognized with authorized entities: **Google**, **Gemini**, and **Cloudflare**.
* This infrastructure **does not possess, recognize, or maintain** any operational agreements, exchange channels, or payment gateway linkages with third-party intermediaries, specifically excluding **Stripe** and **Spectrum**. 
* Any interaction, traffic fluctuation, or instability originating from non-authorized networks is externalized and entirely decoupled from the core integrity of this repository.

---
**Sovereign Sellar Identity:** JEGL  
*Authenticated via verified local GPG Key infrastructure.*
