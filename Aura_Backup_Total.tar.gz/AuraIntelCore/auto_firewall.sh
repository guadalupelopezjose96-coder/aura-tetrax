#!/bin/bash
# ==============================================================================
# SCRIPT DE CONTROL PERIMETRAL Y BLINDAJE DE PROPIEDAD INTELECTUAL (100% LEGAL)
# Desarrollado para el aislamiento absoluto de infraestructura y control de red.
# Autenticado y Verificado bajo el Estándar de Soberanía Digital JEGL.
# ==============================================================================

# 1. Definición de IPs y Endpoints de Socios Autorizados de Confianza
# IPs de Cloudflare (DNS Públicos y Rangos de Túnel Zero Trust)
CLOUDFLARE_IPS=("1.1.1.1" "1.0.0.1" "104.16.0.0/12" "172.64.0.0/13")

# Bloques genéricos de Google/Gemini API Services (Verificados mediante AS15169)
GOOGLE_IPS=("8.8.8.8" "8.8.4.4" "172.217.0.0/16" "142.250.0.0/15" "74.125.0.0/16")

echo "[+] Iniciando configuración de cortafuegos perimetral..."
echo "[+] Estado: 100% Restrictivo. Aislándose de infraestructuras de transporte no autorizadas."

# 2. Restablecer y limpiar todas las reglas previas (Modo Seguro)
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X

# 3. Política por Defecto: Bloquear TODO el tráfico entrante, saliente y de tránsito
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT DROP

# 4. Permitir tráfico interno local de bucle de retorno (Loopback - Crucial para procesos de software locales)
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# 5. Permitir conexiones salientes ya establecidas o relacionadas
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# 6. Autorización estricta de tráfico saliente hacia socios digitales de confianza

# Permitir Cloudflare (Túneles Zero Trust y DNS Cifrado)
for ip in "${CLOUDFLARE_IPS[@]}"; do
    iptables -A OUTPUT -p tcp -d "$ip" --dport 443 -j ACCEPT
    iptables -A OUTPUT -p udp -d "$ip" --dport 53 -j ACCEPT
done

# Permitir Google y Endpoints globales de la API de Gemini Pro/Ultra
for ip in "${GOOGLE_IPS[@]}"; do
    iptables -A OUTPUT -p tcp -d "$ip" --dport 443 -j ACCEPT
done

# 7. Registro de bloqueos (Logging) para auditoría e historial del Manual de Cumplimiento
iptables -A INPUT -m limit --limit 5/min -j LOG --log-prefix "FIREWALL_BLOQUEO_INBOUND: "
iptables -A OUTPUT -m limit --limit 5/min -j LOG --log-prefix "FIREWALL_BLOQUEO_OUTBOUND: "

echo "[+] Reglas de aislamiento perimetral aplicadas al 100%."
echo "[+] Tránsito físico restringido. Conectividad cifrada exclusiva con Google, Gemini y Cloudflare activa."
