# AVISO LEGAL Y TÉRMINOS DE USO - SISTEMAS JEGL

## 1. PROPIEDAD INTELECTUAL
Este software, incluyendo los módulos "Tetrax Engine Pro" y "Elite", es propiedad exclusiva y privada de JEGL. El código fuente, los binarios compilados y la arquitectura lógica están protegidos bajo Copyright © 2026 JEGL.

## 2. RESTRICCIONES DE ACCESO
El uso de los módulos Pro/Elite está estrictamente limitado a usuarios autorizados mediante llave criptográfica (Token). Queda prohibida la redistribución, ingeniería inversa, descompilación o intento de alteración del motor de procesamiento.

## 3. PROTOCOLO DE AUDITORÍA Y SEGURIDAD
El sistema Aura Intel Core integra un protocolo de vigilancia de integridad (audit_check). Cualquier modificación no autorizada, intento de bypass o detección de manipulación en el binario principal (`motor_paralelo`) activará protocolos de bloqueo inmediato.

## 4. LIMITACIÓN DE RESPONSABILIDAD
El acceso a la potencia de los 76 núcleos conlleva riesgos operativos. JEGL no se hace responsable por daños en el hardware si se fuerzan parámetros fuera de la configuración segura de fábrica.

---
[CONTACTO: Soporte Oficial JEGL - Ecosistema Privado]
