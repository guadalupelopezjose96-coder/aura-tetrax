,#!/bin/bash
TARGET="192.168.1.122"
if ping -c 1 $TARGET &> /dev/null
then
  echo "[+] $(date): Bóveda iPad EN LÍNEA al 100%." >> /data/data/com.termux/files/home/jegl_system.log
else
  echo "[!] $(date): ALERTA - Bóveda inalcanzable." >> /data/data/com.termux/files/home/jegl_system.log
fi

