#!/bin/bash
# ==============================================================================
# SCRIPT DE FIRMA DIGITAL Y CONTROL DE INTEGRIDAD CRIPTOGRÁFICA (100% LEGAL)
# Diseñado para la verificación inalterable de manifiestos y activos propietarios.
# Autenticado y Verificado bajo el Estándar de Soberanía Digital JEGL.
# ==============================================================================

# Configuración de rutas e identidad
MANIFIESTO="manifiesto_arquitectura.json" # Archivo central a proteger
KEY_ID="74B98C90F41606C56FC3560ED1632F6FEDF6DE07"
HISTORIAL_INTEGRIDAD="checksums.sha256"   # Registro inalterable de hashes

echo "[+] Iniciando operaciones criptográficas de control perimetral..."
echo "[+] Identidad de Firma Activa: $KEY_ID"

# 1. Validación de la existencia del archivo o módulo central
if [ ! -f "$MANIFIESTO" ]; then
    echo "[-] Error: No se encontró el archivo $MANIFIESTO para firmar."
    exit 1
fi

# 2. Generación automática del Hash SHA-256 (Integridad Matemática)
echo "[+] Generando huella digital SHA-256 del manifiesto..."
sha256sum "$MANIFIESTO" > "$HISTORIAL_INTEGRIDAD"
echo "[+] Hash generado exitosamente en: $HISTORIAL_INTEGRIDAD"

# 3. Firma Digital Asimétrica (Autenticidad y No Repudio)
# Crea un archivo de firma desprendida (.sig) usando tu llave GPG/ED25519
echo "[+] Firmando digitalmente el manifiesto con la identidad $KEY_ID..."
gpg --batch --yes --local-user "$KEY_ID" --detach-sign --armor --output "${MANIFIESTO}.sig" "$MANIFIESTO"

if [ $? -eq 0 ]; then
    echo "[+] SISTEMA GLOBAL INTEGRADO EXITOSAMENTE [100% LEGAL]"
    echo "[+] Archivo de firma creado: ${MANIFIESTO}.sig"
else
    echo "[-] Error: Falló el proceso de firma digital. Verifique sus llaves GPG."
    exit 1
fi

# 4. Proceso Automatizado de Verificación (Función de Auditoría Externa)
echo "----------------------------------------------------------------------"
echo "[+] Ejecutando simulación de auditoría de integridad técnica..."

# Validación del Hash SHA-256
sha256sum -c "$HISTORIAL_INTEGRIDAD" --status
if [ $? -eq 0 ]; then
    echo "[+] VERIFICACIÓN DE HASH: 100% INTEGRO (Sin alteraciones físicas)"
else
    echo "[-] ALERTA DE SEGURIDAD: El manifiesto ha sido modificado ilícitamente."
    exit 1
fi

# Validación de la Firma GPG
gpg --verify "${MANIFIESTO}.sig" "$MANIFIESTO" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "[+] VERIFICACIÓN DE FIRMA: 100% AUTÉNTICO (Origen verificado por JEGL)"
else
    echo "[-] ALERTA DE SEGURIDAD: La firma digital no coincide o no es válida."
    exit 1
fi

echo "----------------------------------------------------------------------"
echo "[+] Operaciones criptográficas debidas completadas al 100%."
