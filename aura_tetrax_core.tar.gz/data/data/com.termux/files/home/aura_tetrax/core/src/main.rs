// MÓDULO PRINCIPAL DE EJECUCIÓN | AURA-TETRAX
// Blindaje FESM 1979 | Integridad 100%

mod engine; // Importa tu módulo de motor
use engine::HexakisEngine;

// Simulación de una llave de verificación soberana
fn obtener_llave_soberana() -> String {
    "FESM-KEY-1979-100".to_string()
}

fn main() {
    println!("[Sistema Soberano] Iniciando núcleo Rust...");

    // 1. Inicialización del motor con nombre registrado
    let engine = HexakisEngine { 
        nombre_motor: "Aura-Tetrax-Core".to_string() 
    };

    // 2. Definición de la llave de auditoría
    let key = obtener_llave_soberana(); 

    // 3. Activación del método de auditoría (Elimina el warning de "unused method")
    // Esto asegura que el motor ha pasado la validación antes de operar
    engine.verificar_integridad(&key); 

    println!("[Soberanía Activa] Motor inicializado al 100%.");
    println!("[Estado] HexakisEngine en línea bajo estándares FESM.");
}
